import 'package:contato/view/contato_page.dart';
import 'package:contato/view/home.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    //home: HomePage(),
    home: HomePage(),
  ));
}

